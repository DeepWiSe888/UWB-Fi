# PicoScenes Plug-In Development Kit (PS-PDK)

This repository hold the code of three PicoScenes plugins, Demo plugin, EchoProbe, and Packet Forwarder.

## Issue Tracker only for PS-PDK and three plugins

The general issues about PicoScenes should be arised in the dedicated [PicoScenes Issue Tracker](https://gitlab.com/wifisensing/picoscenes-issue-tracker/-/issues).
