//
// Created by Zhiping Jiang on 11/18/17.
//

#include <boost/algorithm/string/predicate.hpp>
#include <regex>
#include "EchoProbePlugin.hxx"


std::string EchoProbePlugin::getPluginName() {
    return "Echo_Probe";
}

std::string EchoProbePlugin::getPluginDescription() {
    return "Echo Probe, a round-trip CSI measurement plugin.";
}

std::string EchoProbePlugin::pluginStatus() {
    return "";
}

void EchoProbePlugin::initialization() {
    initiator = std::make_shared<EchoProbeInitiator>(std::dynamic_pointer_cast<AbstractNIC>(nic));
    responder = std::make_shared<EchoProbeResponder>(std::dynamic_pointer_cast<AbstractNIC>(nic));


    injectionOptions = std::make_shared<po::options_description>("EchoProbe Initiator Options", 120);
    injectionOptions->add_options()
            ("target-mac-address", po::value<std::string>(), "MAC address of the injection target [ magic Intel 00:16:ea:12:34:56 is default]")
            ("5300", "Both Destination and Source MAC addresses are set to 'magic Intel 00:16:ea:12:34:56'")

            ("cf", po::value<std::string>(), "MATLAB-style specification for carrier frequency scan range, format begin:step:end, e.g., 5200e6:20e6:5800e6")
            ("sf", po::value<std::string>(), "MATLAB-style specification for baseband sampling frequency multiplier scan range, format begin:step:end, e.g., 11:11:88")
            ("repeat", po::value<std::string>(), "The injection number per cf/bw combination, 100 as default")
            ("delay", po::value<std::string>(), "The delay between successive injections(unit in us, 5e5 as default)")
            ("delayed-start", po::value<uint32_t>(), "A one-time delay before injection(unit in us, 0 as default)")
            ("injector-content", po::value<std::string>(), "Content type for injector mode [full, header, ndp]");

    echoOptions = std::make_shared<po::options_description>("Echo Responder Options", 120);
    echoOptions->add_options()
            ("ack-type", po::value<std::string>(), "EchoProbe reply strategy [full, csi, extra, header], full as default")
            ("ack-mcs", po::value<uint32_t>(), "mcs value (for one single spatial stream) for ack packets [0-11], unspecified as default")
            ("ack-sts", po::value<uint32_t>(), "the number of spatial time stream (STS) for ack packets [0-23], unspecified as default")
            ("ack-cbw", po::value<uint32_t>(), "bandwidth for ack packets (unit in MHz) [20, 40, 80, 160], unspecified as default")
            ("ack-gi", po::value<uint32_t>(), "guarding-interval for ack packets [400, 800, 1600, 3200], unspecified as default");

    echoProbeOptions = std::make_shared<po::options_description>("Echo Probe Options");
    echoProbeOptions->add_options()
            ("mode", po::value<std::string>(), "Working mode [injector, logger, initiator, responder]")
            ("random-mac", po::value<bool>()->default_value(false), "Random MAC address for Injector or Initiator")
            ("output", po::value<std::string>(), "Output CSI file name w/o .csi extension");
    echoProbeOptions->add(*injectionOptions).add(*echoOptions);
}

std::shared_ptr<po::options_description> EchoProbePlugin::pluginOptionsDescription() {
    return echoProbeOptions;
}

std::vector<PicoScenesDeviceType> EchoProbePlugin::getSupportedDeviceTypes() {
    static auto supportedDevices = std::vector<PicoScenesDeviceType>{PicoScenesDeviceType::IWL5300, PicoScenesDeviceType::QCA9300, PicoScenesDeviceType::IWLMVM_AX200, PicoScenesDeviceType::IWLMVM_AX210, PicoScenesDeviceType::VirtualSDR, PicoScenesDeviceType::USRP, PicoScenesDeviceType::SoapySDR};
    return supportedDevices;
}

void EchoProbePlugin::parseAndExecuteCommands(const std::string &commandString) {
    po::variables_map vm;
    auto style = pos::allow_long | pos::allow_dash_for_short |
                 pos::long_allow_adjacent | pos::long_allow_next |
                 pos::short_allow_adjacent | pos::short_allow_next;

    po::store(po::command_line_parser(po::split_unix(commandString)).options(*echoProbeOptions).style(style).allow_unregistered().run(), vm);
    po::notify(vm);

    if (vm.count("mode")) {
        auto modeString = vm["mode"].as<std::string>();
        boost::algorithm::to_lower(modeString);
        boost::trim(modeString);

        /**
         * Injector and Logger no logger performs stopTx/Rx() because of loopback mode for SDR multi-channel
         */
        if (modeString.find("injector") != std::string::npos) {
            parameters.workingMode = MODE_Injector;
            nic->startTxService();
        } else if (modeString.find("logger") != std::string::npos) {
            parameters.workingMode = MODE_Logger;
            nic->startRxService();
        } else if (modeString.find("responder") != std::string::npos) {
            parameters.workingMode = MODE_EchoProbeResponder;
            nic->getFrontEnd()->setDestinationMACAddressFilter(std::vector<std::array<uint8_t, 6>>{PicoScenesFrameBuilder::magicIntel123456});
            nic->getFrontEnd()->setSourceMACAddressFilter(std::vector<std::array<uint8_t, 6>>{PicoScenesFrameBuilder::magicIntel123456});
            nic->startRxService();
            nic->startTxService();
        } else if (modeString.find("initiator") != std::string::npos) {
            parameters.workingMode = MODE_EchoProbeInitiator;
            nic->getFrontEnd()->setDestinationMACAddressFilter(std::vector<std::array<uint8_t, 6>>{PicoScenesFrameBuilder::magicIntel123456});
            nic->getFrontEnd()->setSourceMACAddressFilter(std::vector<std::array<uint8_t, 6>>{PicoScenesFrameBuilder::magicIntel123456});
            nic->startRxService();
            nic->startTxService();
        } else
            throw std::invalid_argument("Unsupported --mode option value by EchoProbe plugins.");
    }

    if (vm.count("random-mac")) {
        parameters.randomMAC = vm["random-mac"].as<bool>();
    }

    if (vm.count("output")) {
        auto outputFileName = vm["output"].as<std::string>();
        parameters.outputFileName = outputFileName;
    }

    if (vm.count("target-mac-address")) {
        auto macAddressString = vm["target-mac-address"].as<std::string>();
        std::vector<std::string> eachHexs;
        boost::split(eachHexs, macAddressString, boost::is_any_of(":-"), boost::token_compress_on);
        if (eachHexs.size() != 6)
            LoggingService_warning_print("[target-mac-address] Specified mac address has wrong number of digits.\n");
        else {
            std::array<uint8_t, 6> address = {0};
            for (auto i = 0; i < eachHexs.size() && i < 6; i++) {
                boost::trim(eachHexs[i]);
                auto hex = std::stod("0x" + eachHexs[i]);
                address[i] = hex;
            }

            parameters.inj_target_mac_address = address;
        }
    }

    if (vm.count("5300")) {
        parameters.inj_for_intel5300 = true;
    }
/*
    if (vm.count("cf")) {
        auto rangeString = vm["cf"].as<std::string>();
        std::vector<std::string> rangeParts;
        boost::split(rangeParts, rangeString, boost::is_any_of(":"), boost::token_compress_on);
        if (!rangeParts[0].empty())
            parameters.cf_begin = boost::lexical_cast<double>(rangeParts[0]);
        if (!rangeParts[1].empty())
            parameters.cf_step = boost::lexical_cast<double>(rangeParts[1]);
        if (!rangeParts[2].empty())
            parameters.cf_end = boost::lexical_cast<double>(rangeParts[2]);
    }
*/
    if (vm.count("cf")) {
        auto cfls = vm["cf"].as<std::string>();
        std::vector<std::string> rangeParts;
        #include <regex>
        //std::regex patternA("rand\\[(\\d+(?:,\\d+)*)\\]");
        std::regex patternB("manu\\[(\\d+(?:,\\d+)*)\\]");
        std::regex patternC("line\\[(\\d+(?:,\\d+)*)\\]");
        std::smatch matches;
/*
        if (std::regex_match(cfls, matches, patternA)) {
            std::vector<int> nums;
            std::string numbersStr = matches[1].str();
            std::istringstream iss(numbersStr);
            std::string numStr;
            while (std::getline(iss, numStr, ',')) {
                int num = std::stoi(numStr);
                nums.push_back(num);
            }


            std::vector<double>  cf_optional = { 2412e6, 2437e6, 2462e6,
                                                 5180e6, 5200e6, 5220e6, 5240e6, 5260e6, 5280e6, 5300e6, 5320e6,
                                                 5500e6, 5520e6, 5540e6, 5560e6, 5580e6, 5600e6, 5620e6, 5640e6, 5660e6, 5680e6, 5700e6, 572e6,
                                                 5745e6, 5765e6, 5785e6, 5805e6,
                                                 5955e6, 5975e6, 5995e6, 6015e6, 6035e6, 6055e6, 6075e6, 6095e6, 6115e6, 6135e6, 6155e6, 6175e6,
                                                 6195e6, 6215e6, 6235e6, 6255e6, 6275e6, 6295e6, 6315e6, 6335e6, 6355e6, 6375e6, 6395e6, 6415e6,
                                                 6435e6, 6455e6, 6475e6, 6495e6, 6515e6, 6535e6, 6555e6, 6575e6, 6595e6, 6615e6, 6635e6, 6655e6,
                                                 6675e6, 6695e6, 6715e6, 6735e6, 6755e6, 6775e6, 6795e6, 6815e6, 6835e6, 6855e6, 6875e6, 6895e6,
                                                 6915e6, 6935e6, 6955e6, 6975e6, 6995e6, 7015e6, 7035e6, 7055e6, 7075e6, 7095e6, 7115e6
            };
            // 2.4GHz + 5GHz + 6GHz = 3 + 24 + 59 = 86

            std::vector<int> numbers = generateNumbersInRange(nums[0], nums[1], nums[2]);
            for (int i = 0; i < numbers.size(); i++) {
                double temp = cf_optional[numbers[i]];
                frequencies.emplace_back(temp);
            }

        }
*/
        if (std::regex_match(cfls, matches, patternB)) {
            //std::vector<double> nums;
            std::string numbersStr = matches[1].str();
            std::istringstream iss(numbersStr);
            std::string numStr;
            while (std::getline(iss, numStr, ',')) {
                double num = std::stoi(numStr);
                parameters.cf_begin.push_back(num * 1000000);
            }
            //parameters.cf_begin = nums;
        }

        else if (std::regex_match(cfls, matches, patternC)) {
            std::vector<double> nums;
            std::vector<double> frequencies;
            std::string numbersStr = matches[1].str();
            std::istringstream iss(numbersStr);
            std::string numStr;
            while (std::getline(iss, numStr, ',')) {
                double num = std::stoi(numStr);
                nums.push_back(num*1000000);
            }

            auto cf_begin = nums[0];
            auto cf_step = nums[1];
            auto cf_end = nums[2];
            auto cur_cf = cf_begin;

            do {
                parameters.cf_begin.emplace_back(cur_cf);
                cur_cf += cf_step;
            } while ((cf_step > 0 && cur_cf <= cf_end) || (cf_step < 0 && cur_cf >= cf_end));
        }

        else {
            throw std::runtime_error("An error occurred!");
            std::cout << "Wrong data format" << std::endl;
            printf(
                    "There are three types of the --cf \n"
                    "1. \"manu[2412, 5955, 6115, 6555, 7115]\" means users can input CFs they want (MHz). \n"
                    "2. \"rand[5000, 10, 6000]\" means selecting 10 CFs between 5GHz and 6GHz. \n"
                    "The optional CFs is cf_optional = { 2412e6, 2437e6, 2462e6, \n"
                    "5180e6, 5200e6, 5220e6, 5240e6, 5260e6, 5280e6, 5300e6, 5320e6, \n"
                    "5500e6, 5520e6, 5540e6, 5560e6, 5580e6, 5600e6, 5620e6, 5640e6, 5660e6, 5680e6, 5700e6, 572e6,\n"
                    "5745e6, 5765e6, 5785e6, 5805e6,\n"
                    "5955e6, 5975e6, 5995e6, 6015e6, 6035e6, 6055e6, 6075e6, 6095e6, 6115e6, 6135e6, 6155e6, 6175e6,\n"
                    "6195e6, 6215e6, 6235e6, 6255e6, 6275e6, 6295e6, 6315e6, 6335e6, 6355e6, 6375e6, 6395e6, 6415e6,\n"
                    "6435e6, 6455e6, 6475e6, 6495e6, 6515e6, 6535e6, 6555e6, 6575e6, 6595e6, 6615e6, 6635e6, 6655e6,\n"
                    "6675e6, 6695e6, 6715e6, 6735e6, 6755e6, 6775e6, 6795e6, 6815e6, 6835e6, 6855e6, 6875e6, 6895e6,\n"
                    "6915e6, 6935e6, 6955e6, 6975e6, 6995e6, 7015e6, 7035e6, 7055e6, 7075e6, 7095e6, 7115e6};\n"
                    "3. \"line[5955, 20, 7115]\" means scaning the CFs from 5955MHz to 7115MHz every 20MHz. \n"
                    "4. NOTE: DO NOT forget the ouble quotation mark (\"\") and DO NOT add spaces behand the comma(,). "
            );
        }

        parameters.cf_step = 0;
        parameters.cf_end = 0;
    }

    if (vm.count("sf")) {
        auto rangeString = vm["sf"].as<std::string>();
        std::vector<std::string> rangeParts;
        boost::split(rangeParts, rangeString, boost::is_any_of(":"), boost::token_compress_on);
        if (!rangeParts[0].empty())
            parameters.sf_begin = boost::lexical_cast<double>(rangeParts[0]);
        if (!rangeParts[1].empty())
            parameters.sf_step = boost::lexical_cast<double>(rangeParts[1]);
        if (!rangeParts[2].empty())
            parameters.sf_end = boost::lexical_cast<double>(rangeParts[2]);

        if (nic->getDeviceType() == PicoScenesDeviceType::IWL5300) {
            LoggingService_warning_print("Intel 5300 NIC does not support sampling rate configuration.\n");
            parameters.sf_begin = 0;
            parameters.sf_step = 0;
            parameters.sf_end = 0;
        }
    }

    if (vm.count("repeat")) {
        parameters.cf_repeat = boost::lexical_cast<double>(vm["repeat"].as<std::string>());
    }

    if (vm.count("delay")) {
        parameters.tx_delay_us = boost::lexical_cast<double>(vm["delay"].as<std::string>());
    }

    if (vm.count("delayed-start")) {
        parameters.delayed_start_seconds = vm["delayed-start"].as<uint32_t>();
    }

    if (vm.count("injector-content")) {
        auto codingStr = vm["injector-content"].as<std::string>();
        if (boost::iequals(codingStr, "ndp"))
            parameters.injectorContent = EchoProbeInjectionContent::NDP;
        else if (boost::iequals(codingStr, "header"))
            parameters.injectorContent = EchoProbeInjectionContent::Header;
        else if (boost::iequals(codingStr, "full"))
            parameters.injectorContent = EchoProbeInjectionContent::Full;
    }

    if (vm.count("ack-type")) {
        auto ackType = vm["ack-type"].as<std::string>();
        if (boost::iequals(ackType, "full"))
            parameters.replyStrategy = EchoProbeReplyStrategy::ReplyWithFullPayload;
        else if (boost::iequals(ackType, "csi"))
            parameters.replyStrategy = EchoProbeReplyStrategy::ReplyWithCSI;
        else if (boost::iequals(ackType, "extra"))
            parameters.replyStrategy = EchoProbeReplyStrategy::ReplyWithExtraInfo;
        else if (boost::iequals(ackType, "header"))
            parameters.replyStrategy = EchoProbeReplyStrategy::ReplyOnlyHeader;
    }

    if (vm.count("ack-mcs")) {
        auto mcsValue = vm["ack-mcs"].as<uint32_t>();
        if (mcsValue <= 11) {
            parameters.ack_mcs = mcsValue;
        } else
            throw std::invalid_argument(fmt::format("[EchoProbe Plugin]: invalid ACK MCS value: {}.\n", mcsValue));
    }

    if (vm.count("ack-sts")) {
        auto ack_sts = vm["ack-sts"].as<uint32_t>();
        parameters.ack_cbw = ack_sts;
    }

    if (vm.count("ack-cbw")) {
        auto ack_bw = vm["ack-cbw"].as<uint32_t>();
        parameters.ack_cbw = ack_bw;
    }

    if (vm.count("ack-gi")) {
        auto giValue = vm["ack-gi"].as<uint32_t>();
        parameters.ack_guardInterval = giValue;
    }

    if (parameters.workingMode == MODE_EchoProbeInitiator || parameters.workingMode == MODE_Injector) {
        initiator->startJob(parameters);
        nic->stopRxService();
        nic->stopTxService();
    } else if (parameters.workingMode == MODE_EchoProbeResponder || parameters.workingMode == MODE_Logger)
        responder->startJob(parameters);
}

void EchoProbePlugin::rxHandle(const ModularPicoScenesRxFrame &rxframe) {
    if (parameters.workingMode == MODE_EchoProbeResponder || parameters.workingMode == MODE_Logger)
        responder->handle(rxframe);
}
